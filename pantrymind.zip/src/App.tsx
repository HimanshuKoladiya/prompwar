import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Camera,
  Plus,
  Trash2,
  Utensils,
  ChefHat,
  CheckCircle2,
  AlertTriangle,
  Activity,
  Info,
  Coins,
  TrendingDown,
  RefreshCw,
  Sliders,
  X,
  Check,
  Loader2,
  Apple,
  Heart,
  UploadCloud,
  HelpCircle
} from "lucide-react";
import { User, InventoryItem, IngredientPricing, DailyPlanResponse } from "./types.js";

// Helper to generate a stable client-side user ID
const getOrGenerateUserId = (): string => {
  let id = localStorage.getItem("pantrymind_user_id");
  if (!id) {
    id = `user-${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem("pantrymind_user_id", id);
  }
  return id;
};

// Preset sample fridge images (base64 or SVG data) to let users test instantly
const SAMPLE_IMAGE_EGGS_VEGGIES = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'><rect width='400' height='400' fill='%231e293b'/><circle cx='100' cy='150' r='40' fill='%23ef4444'/><circle cx='200' cy='180' r='45' fill='%2322c55e'/><circle cx='300' cy='150' r='35' fill='%23f59e0b'/><text x='50' y='320' fill='white' font-family='sans-serif' font-weight='bold' font-size='20'>Sample: Tomatoes &amp; Spinach</text></svg>";
const SAMPLE_IMAGE_RECIPE_BILL = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'><rect width='400' height='400' fill='%230f172a'/><rect x='80' y='50' width='240' height='300' fill='white' rx='10'/><line x1='120' y1='100' x2='280' y2='100' stroke='%23475569' stroke-width='8'/><line x1='120' y1='150' x2='220' y2='150' stroke='%2364748b' stroke-width='6'/><line x1='120' y1='200' x2='260' y2='200' stroke='%2394a3b8' stroke-width='4'/><text x='110' y='320' fill='%230284c7' font-family='monospace' font-weight='bold' font-size='16'>Pantry Receipt Code</text></svg>";

const DIET_OPTIONS = ["None", "Vegetarian", "Vegan", "Keto", "Paleo", "Sub-Continent/Desi"];
const HEALTH_OPTIONS = [
  "Diabetes (Low Glycemic Index)",
  "Hypertension (Low Sodium)",
  "High Cholestorol (Low Saturated Fats)",
  "Muscle Building (High Protein)",
  "Weight Loss (Low Calorie)"
];
const ALLERGY_OPTIONS = ["Peanuts", "Seafood", "Dairy / Lactose", "Gluten / Wheat", "Soy", "Eggs", "Nuts", "Sesame"];

const LANGUAGES = [
  { code: "English", name: "English 🇬🇧" },
  { code: "Hindi", name: "हिंदी 🇮🇳" },
  { code: "Spanish", name: "Español 🇪🇸" },
  { code: "French", name: "Français 🇫🇷" },
  { code: "German", name: "Deutsch 🇩🇪" },
  { code: "Gujarati", name: "ગુજરાતી 🇮🇳" }
];

const PRESET_INGRIDIENTS = [
  { name: "tomato", emoji: "🍅", category: "Vegetable", defaultQty: 500 },
  { name: "onion", emoji: "🧅", category: "Vegetable", defaultQty: 400 },
  { name: "paneer", emoji: "🧀", category: "Dairy", defaultQty: 250 },
  { name: "chicken breast", emoji: "🥩", category: "Meat", defaultQty: 500 },
  { name: "spinach", emoji: "🥬", category: "Vegetable", defaultQty: 200 },
  { name: "garlic", emoji: "🧄", category: "Herbs", defaultQty: 100 },
  { name: "ginger", emoji: "🫚", category: "Herbs", defaultQty: 100 },
  { name: "potato", emoji: "🥔", category: "Vegetable", defaultQty: 800 },
  { name: "mushroom", emoji: "🍄", category: "Vegetable", defaultQty: 250 },
  { name: "bell pepper", emoji: "🫑", category: "Vegetable", defaultQty: 300 },
  { name: "cheese", emoji: "🍕", category: "Dairy", defaultQty: 200 },
  { name: "milk", emoji: "🥛", category: "Dairy", defaultQty: 1000 },
  { name: "eggs", emoji: "🥚", category: "Egg", defaultQty: 600 },
  { name: "butter", emoji: "🧈", category: "Dairy", defaultQty: 200 },
  { name: "rice", emoji: "🍚", category: "Grain", defaultQty: 1000 },
  { name: "flour", emoji: "🫓", category: "Grain", defaultQty: 1000 },
  { name: "carrot", emoji: "🥕", category: "Vegetable", defaultQty: 300 },
  { name: "lemon", emoji: "🍋", category: "Fruit", defaultQty: 150 },
  { name: "cucumber", emoji: "🥒", category: "Vegetable", defaultQty: 400 },
  { name: "banana", emoji: "🍌", category: "Fruit", defaultQty: 600 },
  { name: "apple", emoji: "🍎", category: "Fruit", defaultQty: 500 },
  { name: "yogurt", emoji: "🥛", category: "Dairy", defaultQty: 400 },
  { name: "coriander", emoji: "🌿", category: "Herbs", defaultQty: 50 },
  { name: "chili", emoji: "🌶️", category: "Herbs", defaultQty: 100 }
];

const getIngredientEmoji = (name: string): string => {
  const clean = name.trim().toLowerCase();
  const found = PRESET_INGRIDIENTS.find(p => clean.includes(p.name) || p.name.includes(clean));
  return found ? found.emoji : "🥗";
};

const isIngredientAllowed = (
  name: string,
  category: string,
  diet: string,
  allergies: string[]
): boolean => {
  const cleanName = name.toLowerCase();
  const cleanCat = category.toLowerCase();

  // 1. Check Diet Restrictions
  if (diet === "Vegetarian") {
    if (
      cleanCat === "meat" ||
      cleanCat === "seafood" ||
      cleanName.includes("chicken") ||
      cleanName.includes("fish") ||
      cleanName.includes("meat") ||
      cleanName.includes("beef") ||
      cleanName.includes("pork") ||
      cleanName.includes("bacon")
    ) {
      return false;
    }
  }

  if (diet === "Vegan") {
    if (
      cleanCat === "meat" ||
      cleanCat === "seafood" ||
      cleanCat === "dairy" ||
      cleanCat === "egg" ||
      cleanName.includes("chicken") ||
      cleanName.includes("fish") ||
      cleanName.includes("meat") ||
      cleanName.includes("paneer") ||
      cleanName.includes("cheese") ||
      cleanName.includes("milk") ||
      cleanName.includes("butter") ||
      cleanName.includes("egg") ||
      cleanName.includes("yogurt") ||
      cleanName.includes("honey")
    ) {
      return false;
    }
  }

  if (diet === "Keto") {
    if (
      cleanCat === "grain" ||
      cleanName.includes("rice") ||
      cleanName.includes("flour") ||
      cleanName.includes("banana") ||
      cleanName.includes("apple") ||
      cleanName.includes("potato") ||
      cleanName.includes("sugar")
    ) {
      return false;
    }
  }

  if (diet === "Paleo") {
    if (
      cleanCat === "grain" ||
      cleanCat === "dairy" ||
      cleanName.includes("rice") ||
      cleanName.includes("flour") ||
      cleanName.includes("paneer") ||
      cleanName.includes("cheese") ||
      cleanName.includes("milk") ||
      cleanName.includes("butter") ||
      cleanName.includes("yogurt")
    ) {
      return false;
    }
  }

  // 2. Check Allergies
  for (const allergy of allergies) {
    const cleanAllergy = allergy.toLowerCase();
    if (cleanAllergy.includes("dairy") || cleanAllergy.includes("lactose")) {
      if (
        cleanCat === "dairy" ||
        cleanName.includes("milk") ||
        cleanName.includes("cheese") ||
        cleanName.includes("paneer") ||
        cleanName.includes("butter") ||
        cleanName.includes("yogurt")
      ) {
        return false;
      }
    }
    if (cleanAllergy.includes("egg")) {
      if (cleanCat === "egg" || cleanName.includes("egg")) {
        return false;
      }
    }
    if (cleanAllergy.includes("shrimp") || cleanAllergy.includes("seafood") || cleanAllergy.includes("fish")) {
      if (
        cleanCat === "seafood" ||
        cleanName.includes("seafood") ||
        cleanName.includes("fish") ||
        cleanName.includes("prawn") ||
        cleanName.includes("shrimp")
      ) {
        return false;
      }
    }
    if (cleanAllergy.includes("gluten") || cleanAllergy.includes("wheat")) {
      if (
        cleanName.includes("flour") ||
        cleanName.includes("wheat") ||
        cleanName.includes("bread") ||
        cleanName.includes("pasta")
      ) {
        return false;
      }
    }
    if (cleanAllergy.includes("peanut")) {
      if (cleanName.includes("peanut")) {
        return false;
      }
    }
    if (cleanAllergy.includes("nut")) {
      if (
        cleanName.includes("nut") ||
        cleanName.includes("almond") ||
        cleanName.includes("cashew") ||
        cleanName.includes("walnut")
      ) {
        return false;
      }
    }
    if (cleanAllergy.includes("soy")) {
      if (cleanName.includes("soy") || cleanName.includes("tofu")) {
        return false;
      }
    }
    if (cleanAllergy.includes("sesame")) {
      if (cleanName.includes("sesame") || cleanName.includes("tahini")) {
        return false;
      }
    }
  }

  return true;
};

const TRANSLATIONS: Record<string, Record<string, string>> = {
  English: {
    pantry_goods: "Pantry Goods Inventory 🍏",
    total_metrics: "Total metrics loaded:",
    clear_all: "Clear All 🧹",
    snap_drag: "Snap or Drag fridge / receipt snapshot to Analyze 📷",
    or_add_manual: "Or add item manually ✏️",
    add_manually_placeholder: "e.g. Paneer, Chicken breast, Tomato...",
    add_item_btn: "Add Item ➕",
    empty_pantry: "Inventory rack is currently empty. Please use the camera upload or manual tool. 📭",
    nutrient_planner: "AI Nutrient Planner 🧠",
    nutrient_desc: "Takes your health parameters & stocked pantry ratios to formulate breakfast, lunch, and dinner. Restricts allergy options perfectly. 🥗",
    plan_day_btn: "Plan My Day 🍳",
    generating_plan: "Formulating Plan... ⏳",
    expenditure_tracker: "Daily Cooking Expenditure Tracker 💰",
    approx_budget: "used / budget limit 🎯",
    budget_warning: "Warning: Plan is approaching your daily budget limit! ⚠️",
    budget_ok: "Plan is under daily budget targets. Excellent savings. 🎉",
    prep_time: "mins ⏱️",
    ingredients_used: "Ingredients 🥦",
    swap_btn: "Swap 🔄",
    checklist_title: "Culinary Checklist & Prep Steps 📋",
    checklist_desc: "Mark off steps chronologically while you cook your meals today.",
    grocery_title: "Grocery Needs & Shopping List 🛒",
    grocery_desc: "Ingredients needed. Pantry stock items highlighted in green.",
    in_pantry: "In Pantry ✅",
    needs_buying: "Needs buying 🛒",
    onboarding_btn: "Onboarding Profile 👤",
    budget_label: "Adjust Budget Directly 💵",
    quick_add_title: "Quick-Add Ingredients Suggestions ✨",
    quick_add_search: "Search ingredients dictionary... 🔍",
    quick_add_desc: "Tap any item to instantenously stock your pantry rack! ⚡",
    budget_limit: "Budget Limit: ",
    adjust_pantry: "Adjust Pantry",
    weekly_streak: "⚡ Active Cooking Streak: 5 Days!",
  },
  Hindi: {
    pantry_goods: "रसोई सामग्री सूची 🍏",
    total_metrics: "कुल मात्रा दर्ज:",
    clear_all: "सभी हटाएँ 🧹",
    snap_drag: "फ्रिज या रसीद की फोटो खींचें/अपलोड करें 📷",
    or_add_manual: "या मैन्युअल रूप से जोड़ें ✏️",
    add_manually_placeholder: "जैसे: पनीर, टमाटर, प्याज...",
    add_item_btn: "जोड़ें ➕",
    empty_pantry: "सामग्री सूची अभी खाली है। कृपया फ़ोटो अपलोड करें या मैन्युअल उपयोग करें। 📭",
    nutrient_planner: "एआई स्मार्ट भोजन नियोजक 🧠",
    nutrient_desc: "स्वस्थ और स्वादिष्ट भोजन तैयार करने के लिए आपकी स्वास्थ्य आवश्यकताओं का तालमेल बिठाता है। 🥗",
    plan_day_btn: "मेरा भोजन प्लान करें 🍳",
    generating_plan: "प्लान तैयार हो रहा है... ⏳",
    expenditure_tracker: "दैनिक खाना पकाने का बजट ट्रैकर 💰",
    approx_budget: "उपयोग किया / बजट सीमा 🎯",
    budget_warning: "चेतावनी: योजना आपके दैनिक बजट सीमा के करीब है! ⚠️",
    budget_ok: "योजना बजट सीमा के भीतर है। बहुत बढ़िया बचत! 🎉",
    prep_time: "मिनट ⏱️",
    ingredients_used: "सामग्री 🥦",
    swap_btn: "बदलें 🔄",
    checklist_title: "खाना पकाने की विधि और चरण 📋",
    checklist_desc: "आज खाना बनाते समय चरणों पर सही का निशान लगाएं।",
    grocery_title: "किराना और खरीदारी की सूची 🛒",
    grocery_desc: "आवश्यक सामग्री। रसोई में मौजूद चीज़ें हरे रंग में दिखाई गई हैं।",
    in_pantry: "रसोई में मौजूद ✅",
    needs_buying: "खरीदना होगा 🛒",
    onboarding_btn: "प्रोफ़ाइल सेटिंग्स 👤",
    budget_label: "बजट को सीधे समायोजित करें 💵",
    quick_add_title: "त्वरित-जोड़ें सामग्री सुझाव ✨",
    quick_add_search: "सामग्री खोजें... 🔍",
    quick_add_desc: "अपनी रसोई में तुरंत सामान जोड़ने के लिए किसी भी चीज़ पर टैप करें! ⚡",
    budget_limit: "बजट सीमा: ",
    adjust_pantry: "रसोई समायोजित करें",
    weekly_streak: "⚡ सक्रिय कुकिंग स्ट्रीक: 5 दिन!",
  },
  Spanish: {
    pantry_goods: "Inventario de Despensa 🍏",
    total_metrics: "Métricas totales cargadas:",
    clear_all: "Limpiar Todo 🧹",
    snap_drag: "Suba o arrastre una foto de su nevera o recibo 📷",
    or_add_manual: "O agregue un ingrediente manualmente ✏️",
    add_manually_placeholder: "ej. Queso, Pechuga de pollo, Tomate...",
    add_item_btn: "Agregar ➕",
    empty_pantry: "El inventario está vacío. Use la cámara o el formulario manual. 📭",
    nutrient_planner: "Planificador de Nutrientes Esencial 🧠",
    nutrient_desc: "Optimiza desayunos, almuerzos y cenas respetando alergias y presupuestos. 🥗",
    plan_day_btn: "Planificar Mi Día 🍳",
    generating_plan: "Formulando Plan... ⏳",
    expenditure_tracker: "Seguimiento de Gastos Diarios de Cocina 💰",
    approx_budget: "usado / límite de presupuesto 🎯",
    budget_warning: "Advertencia: ¡El plan se acerca a su límite de presupuesto diario! ⚠️",
    budget_ok: "El plan está por debajo de su presupuesto. ¡Excelente ahorro! 🎉",
    prep_time: "minutos ⏱️",
    ingredients_used: "Ingredientes 🥦",
    swap_btn: "Intercambiar 🔄",
    checklist_title: "Lista de Verificación de Cocina 📋",
    checklist_desc: "Marque los pasos cronológicamente mientras cocina hoy.",
    grocery_title: "Lista de Compras de Supermercado 🛒",
    grocery_desc: "Ingredientes requeridos. Los que ya tiene están en verde.",
    in_pantry: "En Despensa ✅",
    needs_buying: "Comprar 🛒",
    onboarding_btn: "Perfil de Usuario 👤",
    budget_label: "Ajustar Presupuesto Directamente 💵",
    quick_add_title: "Sugerencias de Adición Rápida ✨",
    quick_add_search: "Buscar ingredientes... 🔍",
    quick_add_desc: "¡Toque cualquier ingrediente para guardarlo al instante! ⚡",
    budget_limit: "Límite de Presupuesto: ",
    adjust_pantry: "Ajustar Despensa",
    weekly_streak: "⚡ ¡Racha de cocina activa: 5 días!",
  },
  French: {
    pantry_goods: "Inventaire de la Cuisine 🍏",
    total_metrics: "Ingrédients totaux chargés :",
    clear_all: "Tout effacer 🧹",
    snap_drag: "Prenez en photo ou glissez une image de votre frigo 📷",
    or_add_manual: "Ou ajoutez un élément manuellement ✏️",
    add_manually_placeholder: "ex. Fromage, Poulet, Tomate...",
    add_item_btn: "Ajouter ➕",
    empty_pantry: "L'inventaire est actuellement vide. Utilisez l'appareil photo ou le formulaire. 📭",
    nutrient_planner: "Planificateur de Nutriments IA 🧠",
    nutrient_desc: "Formule vos repas basés sur vos critères de santé, d'allergies et de budget. 🥗",
    plan_day_btn: "Planifier Ma Journée 🍳",
    generating_plan: "Planification en cours... ⏳",
    expenditure_tracker: "Suivi des Dépenses de Cuisine 💰",
    approx_budget: "utilisé / limite de budget 🎯",
    budget_warning: "Attention : Le plan approche de votre limite budgétaire quotidienne ! ⚠️",
    budget_ok: "Le plan respecte votre budget. Excellentes économies ! 🎉",
    prep_time: "min ⏱️",
    ingredients_used: "Ingrédients 🥦",
    swap_btn: "Remplacer 🔄",
    checklist_title: "Check-list Culinaire & Préparatifs 📋",
    checklist_desc: "Cochez les étapes de préparation au fur et à mesure aujourd'hui.",
    grocery_title: "Liste de Courses 🛒",
    grocery_desc: "Ingrédients nécessaires. Les articles déjà en stock sont en vert.",
    in_pantry: "En Stock ✅",
    needs_buying: "À Acheter 🛒",
    onboarding_btn: "Profil Utilisateur 👤",
    budget_label: "Ajuster le Budget Directement 💵",
    quick_add_title: "Ajouts Rapides Recommandés ✨",
    quick_add_search: "Rechercher un ingrédient... 🔍",
    quick_add_desc: "Appuyez sur un ingrédient pour l'ajouter instantanément ! ⚡",
    budget_limit: "Limite de Budget : ",
    adjust_pantry: "Ajuster la Cuisine",
    weekly_streak: "⚡ Série de cuisine active : 5 jours !",
  },
  German: {
    pantry_goods: "Vorratskammer-Inventar 🍏",
    total_metrics: "Geladene Elemente gesamt:",
    clear_all: "Alles löschen 🧹",
    snap_drag: "Ziehen Sie ein Foto des Kühlschranks oder Kassenbons hierher 📷",
    or_add_manual: "Oder Element manuell hinzufügen ✏️",
    add_manually_placeholder: "z.B. Käse, Hähnchenbrust, Tomate...",
    add_item_btn: "Hinzufügen ➕",
    empty_pantry: "Das Vorratsregal ist leer. Nutze Kamerabild oder manuelle Eingabe. 📭",
    nutrient_planner: "KI-Nährstoff-Planer 🧠",
    nutrient_desc: "Berücksichtigt Gesundheitsdaten und Bestände für Frühstück, Mittag- & Abendessen. 🥗",
    plan_day_btn: "Tag planen 🍳",
    generating_plan: "Plan wird berechnet... ⏳",
    expenditure_tracker: "Ausgabenrechner für die Küche 💰",
    approx_budget: "verwendet / Budgetgrenze 🎯",
    budget_warning: "Achtung: Der Plan nähert sich Ihrem täglichen Budgetlimit! ⚠️",
    budget_ok: "Plan liegt unter dem Tagesbudget. Hervorragende Ersparnis! 🎉",
    prep_time: "Min ⏱️",
    ingredients_used: "Zutaten 🥦",
    swap_btn: "Tauschen 🔄",
    checklist_title: "Kulinarische Checkliste & Schritte 📋",
    checklist_desc: "Haken Sie die Schritte chronologisch ab, während Sie heute kochen.",
    grocery_title: "Einkaufsliste & Bedarf 🛒",
    grocery_desc: "Zutaten benötigt. Vorräte im Besitz sind grün markiert.",
    in_pantry: "Vorhanden ✅",
    needs_buying: "Kaufen 🛒",
    onboarding_btn: "Onboarding-Profil 👤",
    budget_label: "Budget direkt anpassen 💵",
    quick_add_title: "Schnell-Zufügen Vorschläge ✨",
    quick_add_search: "Zutaten suchen... 🔍",
    quick_add_desc: "Tippe auf eine Zutat, um sie sofort ins Regal zu packen! ⚡",
    budget_limit: "Budgetgrenze: ",
    adjust_pantry: "Vorräte anpassen",
    weekly_streak: "⚡ Koch-Streak aktiv: 5 Tage!",
  },
  Gujarati: {
    pantry_goods: "રસોડું સામગ્રી યાદી 🍏",
    total_metrics: "કુલ વસ્તુઓ ઉપલબ્ધ:",
    clear_all: "બધું ભૂંસી નાખો 🧹",
    snap_drag: "ફ્રિજ અથવા ખરીદીની રસીદનો ફોટો અપલોડ કરો 📷",
    or_add_manual: "અથવા વસ્તુ મેન્યુઅલ ઉમેરો ✏️",
    add_manually_placeholder: "દા.ત. પનીર, ચિકન, ટામેટા...",
    add_item_btn: "ઉમેરો ➕",
    empty_pantry: "સામગ્રી યાદી ખાલી છે. ફોટો અથવા મેન્યુઅલ ફોર્મ વાપરો. 📭",
    nutrient_planner: "AI ન્યુટ્રિએન્ટ આયોજક 🧠",
    nutrient_desc: "તમારી એલર્જી અને બજેટ મર્યાદાનું ધ્યાન રાખીને આખા દિવસનો ભોજન પ્લાન બનાવે છે. 🥗",
    plan_day_btn: "મારો ભોજન પ્લાન બનાવો 🍳",
    generating_plan: "પ્લાન બની રહ્યો છે... ⏳",
    expenditure_tracker: "દૈનિક રસોઈ બજેટ ટ્રેકર 💰",
    approx_budget: "વપરાયેલું / બજેટ મર્યાદા 🎯",
    budget_warning: "ચેતવણી: આ પ્લાન તમારા દૈનિક બજેટની મર્યાદાની નજીક છે! ⚠️",
    budget_ok: "ભોજન પ્લાન બજેટ મર્યાદા અંદર છે. સરસ બચત! 🎉",
    prep_time: "મિનિટ ⏱️",
    ingredients_used: "સામગ્રી 🥦",
    swap_btn: "બદલો 🔄",
    checklist_title: "રસોઈ માટેની સ્ટેપ-બાય-સ્ટેપ યાદી 📋",
    checklist_desc: "આજે રસોઈ બનાવતી વખતે સ્ટેપ્સ પર સહીનું નિશાન પ્રતીક કરો.",
    grocery_title: "શાકભાજી અને કરિયાણાની ખરીદી યાદી 🛒",
    grocery_desc: "જરૂરી સામગ્રી. ઘરમાં ઉપલબ્ધ વસ્તુઓ લીલા રંગમાં દર્શાવેલી છે.",
    in_pantry: "ઘરમાં ઉપલબ્ધ ✅",
    needs_buying: "ખરીદવાની જરૂર છે 🛒",
    onboarding_btn: "પ્રોફાઇલ સેટિંગ્સ 👤",
    budget_label: "બજેટ સુધારો 💵",
    quick_add_title: "ઝડપી-ઉમેરો શાકભાજી સૂચનો ✨",
    quick_add_search: "શાકભાજી શોધો... 🔍",
    quick_add_desc: "કોઈપણ વસ્તુ પર ટેપ કરીને તમારા સ્ટોકમાં ઉમેરો! ⚡",
    budget_limit: "બજેટ મર્યાદા: ",
    adjust_pantry: "સામગ્રી બદલો",
    weekly_streak: "⚡ સક્રિય કુકિંગ સ્ટ્રીક: ૫ દિવસ!",
  }
};

export default function App() {
  const userId = getOrGenerateUserId();

  // Onboarding state
  const [profile, setProfile] = useState<User | null>(null);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(1);

  // Form states during onboarding/edit
  const [formAge, setFormAge] = useState("Adult");
  const [formDiet, setFormDiet] = useState("None");
  const [formAllergies, setFormAllergies] = useState<string[]>([]);
  const [formHealth, setFormHealth] = useState<string[]>([]);
  const [formBudget, setFormBudget] = useState(600);

  // Active chosen language
  const [language, setLanguage] = useState<string>(() => {
    return localStorage.getItem("pantrymind_language") || "English";
  });

  // Search filter for Quick-add suggetions dictionary
  const [quickAddSearch, setQuickAddSearch] = useState("");

  // Checkbox/ticks for grocery items
  const [completedShopping, setCompletedShopping] = useState<Record<number, boolean>>({});

  // Inventory states
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [newIngName, setNewIngName] = useState("");
  const [newIngQty, setNewIngQty] = useState(200);

  // Pricing configuration
  const [pricing, setPricing] = useState<IngredientPricing[]>([]);

  // Meal Plan states
  const [mealPlan, setMealPlan] = useState<DailyPlanResponse | null>(null);
  const [historyPlans, setHistoryPlans] = useState<any[]>([]);
  const [isPlanning, setIsPlanning] = useState(false);
  const [planError, setPlanError] = useState<string | null>(null);

  // Todo strikeout states
  const [completedTodos, setCompletedTodos] = useState<{ [key: string]: boolean }>({});

  // Vision scanner states
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [visionError, setVisionError] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);

  // Substitution modal states
  const [isSwapModalOpen, setIsSwapModalOpen] = useState(false);
  const [swapTarget, setSwapTarget] = useState<string | null>(null);
  const [swapContext, setSwapContext] = useState<string>("");
  const [swapResults, setSwapResults] = useState<{
    substitute_name: string;
    reason: string;
    cost_difference_inr: number;
    alternative_recipe_steps_brief: string;
  } | null>(null);
  const [isSwapping, setIsSwapping] = useState(false);

  const t = (key: string) => {
    const langDict = TRANSLATIONS[language] || TRANSLATIONS.English;
    return langDict[key] || TRANSLATIONS.English[key] || key;
  };

  // Load profile, inventory, pricing, and history on mount
  useEffect(() => {
    fetchProfile();
    fetchInventory();
    fetchPricing();
    fetchHistory();
  }, []);

  const handleUpdateDirectBudget = async (newBudget: number) => {
    if (!profile) return;
    const updatedProfile = { ...profile, daily_budget: newBudget };
    setProfile(updatedProfile);
    setFormBudget(newBudget); // sync modal view state too

    try {
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: userId,
          age_group: profile.age_group,
          diet: profile.diet,
          allergies: profile.allergies,
          health_conditions: profile.health_conditions,
          daily_budget: newBudget,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setProfile(data.user);
      }
    } catch (err) {
      console.error("Failed to update budget directly:", err);
    }
  };

  const fetchProfile = async () => {
    try {
      const res = await fetch(`/api/users/${userId}`);
      if (res.ok) {
        const data = await res.json();
        setProfile(data);
        // Pre-fill forms
        setFormAge(data.age_group);
        setFormDiet(data.diet);
        setFormAllergies(data.allergies);
        setFormHealth(data.health_conditions);
        setFormBudget(data.daily_budget);
      } else {
        // Trigger onboarding on first visit or if missing user record
        setIsOnboardingOpen(true);
      }
    } catch (err) {
      console.error("Failed to load user profile:", err);
    }
  };

  const fetchInventory = async () => {
    try {
      const res = await fetch(`/api/inventory/${userId}`);
      if (res.ok) {
        const data = await res.json();
        setInventory(data);
      }
    } catch (err) {
      console.error("Failed to load inventory:", err);
    }
  };

  const fetchPricing = async () => {
    try {
      const res = await fetch("/api/pricing");
      if (res.ok) {
        const data = await res.json();
        setPricing(data);
      }
    } catch (err) {
      console.error("Failed to load pricing table:", err);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await fetch(`/api/meal-history/${userId}`);
      if (res.ok) {
        const data = await res.json();
        setHistoryPlans(data);
        if (data.length > 0) {
          // Default to latest meal plan in history on mount if available
          setMealPlan(data[data.length - 1].plan_json);
        }
      }
    } catch (err) {
      console.error("Failed to load meal history:", err);
    }
  };

  const handleSaveProfile = async (closeWindow = true) => {
    try {
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: userId,
          age_group: formAge,
          diet: formDiet,
          allergies: formAllergies,
          health_conditions: formHealth,
          daily_budget: formBudget,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setProfile(data.user);
        if (closeWindow) {
          setIsOnboardingOpen(false);
          setOnboardingStep(1);
        }
      }
    } catch (err) {
      console.error("Failed to save onboarding profile:", err);
    }
  };

  const handleAddManualInventory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIngName.trim()) return;

    try {
      const res = await fetch(`/api/inventory/${userId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ingredient_name: newIngName.trim(),
          quantity: newIngQty,
        }),
      });
      if (res.ok) {
        setNewIngName("");
        setNewIngQty(200);
        await fetchInventory();
      }
    } catch (err) {
      console.error("Failed adding custom ingredient:", err);
    }
  };

  const handleDeleteInventory = async (itemId: string) => {
    try {
      const res = await fetch(`/api/inventory/${userId}/${itemId}`, {
        method: "DELETE",
      });
      if (res.ok) {
        await fetchInventory();
      }
    } catch (err) {
      console.error("Failed deleting inventory ingredient:", err);
    }
  };

  const handleClearInventory = async () => {
    if (!confirm("Are you sure you want to clear your entire stocked inventory list?")) return;
    try {
      const res = await fetch(`/api/inventory/${userId}/clear`, {
        method: "POST",
      });
      if (res.ok) {
        await fetchInventory();
      }
    } catch (err) {
      console.error("Failed to clear inventory:", err);
    }
  };

  // Drag and drop / base64 image parsing implementation
  const processImageFile = async (file: File) => {
    setIsAnalyzing(true);
    setVisionError(null);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        await sendImageAnalysis(base64String);
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      setVisionError(err.message || "Failed to process image file");
      setIsAnalyzing(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processImageFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = () => {
    setDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processImageFile(e.dataTransfer.files[0]);
    }
  };

  // Instant trigger for sample templates to bypass camera requirement in sandboxes
  const triggerSampleVision = async (type: "veggies" | "receipt") => {
    setIsAnalyzing(true);
    setVisionError(null);
    try {
      // In a physical environment, we call the same endpoint with a real picture payload.
      // Here we pass pre-compiled SVGs/Base64 to keep testing instant, seamless, and reliable.
      const sampleBase64 = type === "veggies" 
        ? "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==" // valid micro png
        : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
      
      const payloadBase64 = sampleBase64;
      await sendImageAnalysis(payloadBase64);
    } catch (err: any) {
      setVisionError(err.message || "Failed to analyze template");
      setIsAnalyzing(false);
    }
  };

  const sendImageAnalysis = async (base64Data: string) => {
    try {
      const response = await fetch("/api/vision/analyze-pantry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image: base64Data,
          user_id: userId,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Pantry vision analysis failed.");
      }

      const data = await response.json();
      await fetchInventory();
    } catch (err: any) {
      setVisionError(err.message || "Failed with Gemini API Connection error. Please verify your internet connection.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Call the core planning helper
  const handleGenerateMealPlan = async () => {
    if (!profile) {
      setIsOnboardingOpen(true);
      return;
    }
    setIsPlanning(true);
    setPlanError(null);
    setCompletedTodos({});
    setCompletedShopping({}); // reset shopping ticks on new plan

    try {
      const response = await fetch("/api/planner/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: userId,
          language: language,
        }),
      });

      if (!response.ok) {
        const edata = await response.json();
        throw new Error(edata.error || "Daily planner experienced an error.");
      }

      const data = await response.json();
      setMealPlan(data);
      await fetchHistory();
    } catch (err: any) {
      setPlanError(err.message || "An issue occurred while generating the meal plan.");
    } finally {
      setIsPlanning(false);
    }
  };

  // Launch direct swap call to alternative API
  const handleSwapRequest = (ingredientName: string, mealContext: string) => {
    setSwapTarget(ingredientName);
    setSwapContext(mealContext);
    setSwapResults(null);
    setIsSwapping(false);
    setIsSwapModalOpen(true);
  };

  const handleQuerySubstitute = async () => {
    if (!swapTarget) return;
    setIsSwapping(true);
    try {
      const response = await fetch("/api/planner/substitute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ingredient_to_swap: swapTarget,
          user_id: userId,
          recipe_context: swapContext,
          language: language,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setSwapResults(data);
      } else {
        alert("Failed to find alternative swap choices.");
      }
    } catch (err) {
      console.error("Substitution error:", err);
    } finally {
      setIsSwapping(false);
    }
  };

  const applySubstitute = () => {
    if (!swapResults || !mealPlan || !swapTarget) return;

    // Apply the swap results directly to current state!
    const swappedVal = swapResults.substitute_name;

    // 1. Update meal names if they contain the swapped ingredient or make a notification
    // 2. Also update relevant todo items and grocery lists
    const updatedPlan = { ...mealPlan };

    // Update ingredients lists inside meal cards if tracked
    if (updatedPlan.daily_plan.breakfast.name.toLowerCase().includes(swapTarget.toLowerCase())) {
      updatedPlan.daily_plan.breakfast.name = updatedPlan.daily_plan.breakfast.name.replace(
        new RegExp(swapTarget, "gi"),
        swappedVal
      );
      updatedPlan.daily_plan.breakfast.health_benefit += `. Swapped for ${swappedVal}: ${swapResults.reason}`;
    }
    if (updatedPlan.daily_plan.lunch.name.toLowerCase().includes(swapTarget.toLowerCase())) {
      updatedPlan.daily_plan.lunch.name = updatedPlan.daily_plan.lunch.name.replace(
        new RegExp(swapTarget, "gi"),
        swappedVal
      );
      updatedPlan.daily_plan.lunch.health_benefit += `. Swapped for ${swappedVal}: ${swapResults.reason}`;
    }
    if (updatedPlan.daily_plan.dinner.name.toLowerCase().includes(swapTarget.toLowerCase())) {
      updatedPlan.daily_plan.dinner.name = updatedPlan.daily_plan.dinner.name.replace(
        new RegExp(swapTarget, "gi"),
        swappedVal
      );
      updatedPlan.daily_plan.dinner.health_benefit += `. Swapped for ${swappedVal}: ${swapResults.reason}`;
    }

    // Update grocery list replacement
    updatedPlan.grocery_list = updatedPlan.grocery_list.map((g) => {
      if (g.item.toLowerCase().includes(swapTarget.toLowerCase())) {
         g.item = swappedVal;
         g.est_cost_inr = Math.max(0, g.est_cost_inr + swapResults.cost_difference_inr);
      }
      return g;
    });

    // Update total budget value
    updatedPlan.total_budget_used = Math.max(0, updatedPlan.total_budget_used + swapResults.cost_difference_inr);

    // Update steps
    updatedPlan.chronological_todo_list = updatedPlan.chronological_todo_list.map((todo) => {
      if (todo.task.toLowerCase().includes(swapTarget.toLowerCase())) {
         todo.task = todo.task.replace(new RegExp(swapTarget, "gi"), swappedVal) + ` (${swapResults.alternative_recipe_steps_brief})`;
      }
      return todo;
    });

    setMealPlan(updatedPlan);
    setIsSwapModalOpen(false);
    setSwapTarget(null);
    setSwapResults(null);
  };

  const handleToggleTodo = (idx: number) => {
    setCompletedTodos((prev) => ({
      ...prev,
      [idx]: !prev[idx],
    }));
  };

  const toggleAllergy = (allergy: string) => {
    setFormAllergies((prev) =>
      prev.includes(allergy) ? prev.filter((a) => a !== allergy) : [...prev, allergy]
    );
  };

  const toggleHealth = (condition: string) => {
    setFormHealth((prev) =>
      prev.includes(condition) ? prev.filter((h) => h !== condition) : [...prev, condition]
    );
  };

  // Calculations for dynamic UI elements
  const budgetRatio = profile ? (mealPlan ? mealPlan.total_budget_used / profile.daily_budget : 0) : 0;
  const isBudgetWarning = budgetRatio >= 0.8;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans antialiased">
      {/* HEADER SECTION */}
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-tr from-emerald-500 to-teal-400 p-2.5 rounded-xl text-slate-950 font-bold shadow-lg shadow-emerald-500/10">
              <ChefHat size={24} className="animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-300 bg-clip-text text-transparent">
                PantryMind 🌿
              </h1>
              <span className="text-xs font-mono text-slate-400 font-medium">AI MEAL PLANNER &amp; KITCHEN ENGINE</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Selection Option */}
            <select
              value={language}
              onChange={(e) => {
                const l = e.target.value;
                setLanguage(l);
                localStorage.setItem("pantrymind_language", l);
              }}
              className="bg-slate-800 border border-slate-705 text-xs text-slate-200 rounded-lg px-2.5 py-2 cursor-pointer outline-none focus:border-emerald-500 transition-colors"
            >
              {LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name}
                </option>
              ))}
            </select>

            {profile && (
              <button
                id="edit-profile-btn"
                onClick={() => {
                  setIsOnboardingOpen(true);
                  setOnboardingStep(1);
                }}
                className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-705 cursor-pointer max-h-11 transition-colors"
              >
                <Sliders size={14} />
                <span>{t("onboarding_btn")}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* CORE FRAMEWORK CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {!profile ? (
          /* INITIAL BANNER & HERO INTRO FOR FRESH VISITORS */
          <div className="max-w-3xl mx-auto text-center py-16 px-4">
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-full inline-flex self-center mb-6">
                <ChefHat size={40} />
              </div>
              <h2 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl mb-4">
                Cook smarter, waste less, spend precisely. 🥕🍳
              </h2>
              <p className="text-lg text-slate-400 mb-8 max-w-xl mx-auto leading-relaxed">
                PantryMind is your zero-frictional culinary copilot. Upload a snapshot of your fridge shelf or grocery receipt, align your health profile or budget limits, and receive flawless daily meal paths instantenously.
              </p>
              <button
                id="start-onboard-hero-btn"
                onClick={() => setIsOnboardingOpen(true)}
                className="px-8 py-4 rounded-xl font-bold bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 transition-all shadow-xl shadow-emerald-500/20 text-lg cursor-pointer transform hover:-translate-y-0.5"
              >
                Get Started ⚡
              </button>
            </motion.div>
          </div>
        ) : (
          /* ACTIVE USER WORKSPACE (BENTO GRID PATTERN) */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* LEFT RAIL: USER PREFERENCES & STOCK PANTRY INVENTORY */}
            <section className="lg:col-span-5 space-y-6">
              
              {/* MEMBER WELLNESS BADGE CARD */}
              <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80 shadow-md">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-mono font-bold tracking-wider text-slate-400">YOUR TARGET PREFERENCES 🎯</span>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xxs font-semibold border border-emerald-500/20">
                    <Activity size={10} />
                    <span>{t("weekly_streak")}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-tight">Diet Type 🥗</span>
                    <span className="text-sm font-semibold text-emerald-400">{profile.diet}</span>
                  </div>
                  <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-tight">Daily Budget Limit 💵</span>
                    <span className="text-sm font-semibold text-teal-300 font-mono">{profile.daily_budget} INR</span>
                  </div>
                </div>

                <div className="mt-3 space-y-2">
                  {profile.allergies.length > 0 && (
                    <div className="text-xxs text-slate-400 flex flex-wrap gap-1.5 items-center">
                      <span className="font-bold text-slate-500">Allergies to Avoid ⚠️:</span>
                      {profile.allergies.map((a) => (
                        <span key={a} className="bg-amber-500/10 text-amber-300 border border-amber-500/20 px-1.5 py-0.5 rounded">
                          {a}
                        </span>
                      ))}
                    </div>
                  )}
                  {profile.health_conditions.length > 0 && (
                    <div className="text-xxs text-slate-400 flex flex-wrap gap-1.5 items-center">
                      <span className="font-bold text-slate-500">Conditions 🩺:</span>
                      {profile.health_conditions.map((h) => (
                        <span key={h} className="bg-blue-500/10 text-blue-300 border border-blue-500/20 px-1.5 py-0.5 rounded">
                          {h.split(" ")[0]}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* PANTRY STOCKROOM MANAGING COMPONENT */}
              <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-md font-bold text-slate-100 flex items-center gap-2">
                      <Apple size={18} className="text-emerald-400 animate-pulse" />
                      {t("pantry_goods")}
                    </h3>
                    <p className="text-xs text-slate-400">{t("total_metrics")} {inventory.length} items</p>
                  </div>
                  {inventory.length > 0 && (
                    <button
                      onClick={handleClearInventory}
                      className="text-xxs text-pink-400 font-semibold hover:underline bg-transparent border-0 cursor-pointer"
                    >
                      {t("clear_all")}
                    </button>
                  )}
                </div>

                {/* DRAG AND DROP VISION FILE SCANNER ACCORDING TO SYSTEM HIGHLIGHTS */}
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-xl p-5 text-center transition-all ${
                    dragging
                      ? "border-emerald-400 bg-emerald-500/10"
                      : "border-slate-700 hover:border-slate-600 bg-slate-900/40"
                  }`}
                >
                  <UploadCloud size={32} className="mx-auto text-slate-400 mb-2" />
                  <p className="text-xs font-semibold text-slate-200">
                    {t("snap_drag")}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-1">JPEG, PNG up to 10MB</p>
                  
                  <div className="mt-4 flex items-center justify-center gap-3">
                    <label className="px-3.5 py-2 rounded-lg text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer shadow-md inline-flex items-center gap-1.5">
                      <Camera size={14} />
                      Upload Photo
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageUpload}
                        disabled={isAnalyzing}
                      />
                    </label>
                  </div>

                  {/* SANDBOX OFFLINE TEST TRIGGERS IF USERS DO NOT HAVE READY PHOTOS */}
                  <div className="mt-4 pt-3 border-t border-slate-800 text-left">
                    <span className="text-[9px] font-bold text-slate-500 block uppercase tracking-wider mb-2">No photos nearby? Load sample snapshots:</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => triggerSampleVision("veggies")}
                        type="button"
                        disabled={isAnalyzing}
                        className="flex-1 py-1.5 px-2 text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 cursor-pointer flex items-center justify-center gap-1"
                      >
                        🥒 Tomatoes &amp; Spinach
                      </button>
                      <button
                        onClick={() => triggerSampleVision("receipt")}
                        type="button"
                        disabled={isAnalyzing}
                        className="flex-1 py-1.5 px-2 text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 cursor-pointer flex items-center justify-center gap-1"
                      >
                        🧾 Receipt bill scan
                      </button>
                    </div>
                  </div>
                </div>

                {/* SHOW SCANNER LOADING ENGINE */}
                <AnimatePresence>
                  {isAnalyzing && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-lg text-xs text-emerald-300 flex items-center gap-3"
                    >
                      <Loader2 size={16} className="animate-spin text-emerald-400" />
                      <span>Gemini model is scanning your kitchen image... identifies names and gram weight estimates.</span>
                    </motion.div>
                  )}
                  {visionError && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-pink-500/10 border border-pink-500/20 p-3 rounded-lg text-xs text-pink-300 flex items-center gap-2"
                    >
                      <AlertTriangle size={16} className="text-pink-400" />
                      <span>{visionError}</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* MANUAL ADDTION COMPONENT */}
                <div>
                  <span className="text-xxs font-bold text-slate-450 block uppercase tracking-wider mb-2.5">{t("or_add_manual")}</span>
                  <form onSubmit={handleAddManualInventory} className="flex gap-2">
                    <input
                      type="text"
                      placeholder={t("add_manually_placeholder")}
                      value={newIngName}
                      onChange={(e) => setNewIngName(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-705 px-3 py-2 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                    <div className="w-24 relative">
                      <input
                        type="number"
                        placeholder="Qty"
                        value={newIngQty}
                        onChange={(e) => setNewIngQty(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-705 pl-3 pr-6 py-2 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                      <span className="absolute right-2 top-2.5 text-[10px] text-slate-550 font-bold">g</span>
                    </div>
                    <button
                      type="submit"
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 rounded-lg cursor-pointer"
                    >
                      <Plus size={16} />
                    </button>
                  </form>
                </div>

                {/* QUICK ADD INGREDIENTS SUGGESTIONS FROM INTERACTIVE DICTIONARY */}
                <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80 space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-xxs font-bold text-slate-450 block uppercase tracking-wider">{t("quick_add_title")}</span>
                    {profile && (() => {
                      const allowedCount = PRESET_INGRIDIENTS.filter(p => 
                        isIngredientAllowed(p.name, p.category, profile.diet || "None", profile.allergies || [])
                      ).length;
                      const hiddenCount = PRESET_INGRIDIENTS.length - allowedCount;
                      if (hiddenCount > 0) {
                        return (
                          <span className="text-[10px] bg-pink-500/10 text-pink-400 border border-pink-500/20 px-1.5 py-0.5 rounded animate-pulse font-medium">
                            ⚠️ {hiddenCount} unsuited items hidden
                          </span>
                        );
                      }
                      return null;
                    })()}
                  </div>
                  
                  <input
                    type="text"
                    placeholder={t("quick_add_search")}
                    value={quickAddSearch}
                    onChange={(e) => setQuickAddSearch(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 px-2.5 py-1.5 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />

                  <div className="grid grid-cols-3 gap-1.5 max-h-36 overflow-y-auto pr-1">
                    {PRESET_INGRIDIENTS.filter(p => {
                      const matchesSearch = p.name.toLowerCase().includes(quickAddSearch.toLowerCase());
                      const isAllowed = isIngredientAllowed(
                        p.name, 
                        p.category, 
                        profile?.diet || "None", 
                        profile?.allergies || []
                      );
                      return matchesSearch && isAllowed;
                    })
                      .map(p => (
                        <button
                          key={p.name}
                          onClick={async () => {
                            try {
                              const res = await fetch(`/api/inventory/${userId}`, {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({
                                  ingredient_name: p.name,
                                  quantity: p.defaultQty,
                                }),
                              });
                              if (res.ok) {
                                await fetchInventory();
                              }
                            } catch (err) {
                              console.error("Quick add error:", err);
                            }
                          }}
                          type="button"
                          className="p-1.5 rounded-lg bg-slate-950/60 hover:bg-emerald-500/10 border border-slate-800/50 hover:border-emerald-500/40 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 group"
                        >
                          <span className="text-lg group-hover:scale-110 transition-transform">{p.emoji}</span>
                          <span className="text-[10px] font-semibold text-slate-300 capitalize truncate w-full">{p.name}</span>
                          <span className="text-[8px] font-mono text-slate-500">{p.defaultQty}g</span>
                        </button>
                      ))
                    }
                  </div>
                  <p className="text-[9px] text-slate-500 italic text-center">{t("quick_add_desc")}</p>
                </div>

                {/* PANTRY RACK GRID */}
                <div className="space-y-1.5">
                  <span className="text-xxs font-bold text-slate-450 block uppercase tracking-wider">Your Stacked Pantry 📦</span>
                  <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1.5">
                    {inventory.length === 0 ? (
                      <div className="text-center py-6 text-slate-500 text-xs italic">
                        {t("empty_pantry")}
                      </div>
                    ) : (
                      inventory.map((item) => {
                        const estimatedPrice = pricing.find(
                          (p) => p.ingredient_name.toLowerCase() === item.ingredient_name.toLowerCase()
                        )?.est_price_per_100g || 15;

                        return (
                          <div
                            key={item.id}
                            className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900 hover:bg-slate-800/80 border border-slate-800 transition-colors"
                          >
                            <div className="flex items-center gap-2.5">
                              <span className="text-base">{getIngredientEmoji(item.ingredient_name)}</span>
                              <div>
                                <span className="text-xs font-semibold text-slate-200 capitalize">{item.ingredient_name}</span>
                                <span className="text-[10px] block text-slate-500 font-medium">Est: {estimatedPrice} INR per 100g</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="text-xs font-semibold text-slate-450 bg-slate-950 px-2 py-0.5 rounded-full border border-slate-805">
                                {item.quantity}g
                              </span>
                              <button
                                onClick={() => handleDeleteInventory(item.id)}
                                className="text-slate-500 hover:text-pink-400 p-1 rounded transition-colors cursor-pointer"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </section>

            {/* RIGHT WORKPLACE AND MAIN ACTION MEAL TIMELINE */}
            <section className="lg:col-span-7 space-y-6">

              {/* ACTION HUB GENERATION STATE BAR */}
              <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col items-center justify-center text-center space-y-4">
                <div className="p-3.5 bg-gradient-to-tr from-emerald-500/10 to-teal-400/10 text-emerald-400 rounded-2xl border border-emerald-500/10 animate-bounce">
                  <Utensils size={32} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-100">{t("ai_nutrient_planner")}</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
                    Takes your health parameters &amp; stocked pantry ratios to formulate breakfast, lunch, and dinner. Restricts allergy options perfectly.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    id="plan-my-day-btn"
                    onClick={handleGenerateMealPlan}
                    disabled={isPlanning}
                    className="px-8 py-3.5 rounded-xl font-bold bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 transition-all font-sans text-md cursor-pointer flex items-center gap-2 shadow-lg disabled:opacity-50"
                  >
                    {isPlanning ? (
                      <>
                        <Loader2 size={18} className="animate-spin" />
                        <span>Formulating Plan...</span>
                      </>
                    ) : (
                      <>
                        <ChefHat size={18} />
                        <span>{t("plan_my_day")} ⚡</span>
                      </>
                    )}
                  </button>
                </div>

                {planError && (
                  <div className="bg-pink-500/10 border border-pink-500/20 p-3 rounded-lg text-xs text-pink-300 flex items-center gap-2 max-w-md">
                    <AlertTriangle size={16} className="text-pink-400 flex-shrink-0" />
                    <span className="text-left">{planError}</span>
                  </div>
                )}
              </div>

              {/* RENDER THE ACTIVE DAILY PLAN PLAN IF CREATED */}
              {mealPlan && (
                <div className="space-y-6">
                  
                  {/* SUMMARY DYNAMIC BUDGET BAR WITH DIRECT EDITING CAPABILITY */}
                  <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800 shadow-md space-y-4.5">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <Coins size={16} className="text-yellow-400" />
                        <h4 className="text-xs font-mono font-bold uppercase text-slate-300">Daily Cooking Expenditure Tracker</h4>
                      </div>
                      
                      {/* Direct Budget Adjuster form widget */}
                      <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
                        <span className="text-xxs text-slate-400 font-bold uppercase">Budget Limit:</span>
                        <input
                          type="number"
                          value={profile.daily_budget}
                          onChange={(e) => {
                            const val = Math.max(10, Number(e.target.value));
                            handleUpdateDirectBudget(val);
                          }}
                          className="w-16 bg-slate-950 text-emerald-400 font-mono text-xs text-center border border-slate-800 rounded font-bold py-0.5 focus:outline-none focus:border-emerald-500"
                        />
                        <span className="text-[10px] text-slate-500 font-bold">INR</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs font-bold text-slate-400 font-mono">
                      <span>Total cost: {mealPlan.total_budget_used} INR</span>
                      <span>Target: {profile.daily_budget} INR max</span>
                    </div>

                    {/* Progress indicator */}
                    <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isBudgetWarning ? "bg-amber-500" : "bg-emerald-400"
                        }`}
                        style={{ width: `${Math.min(100, budgetRatio * 100)}%` }}
                      />
                    </div>

                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-1.5 text-xxs text-slate-405">
                        <Info size={11} className="text-slate-500" />
                        {isBudgetWarning ? (
                          <span className="font-semibold text-amber-300">Warning: Plan is approaching your daily budget limit!</span>
                        ) : (
                          <span>Plan is under daily budget targets. Excellent savings.</span>
                        )}
                      </div>
                      {mealPlan.total_budget_used > 0 && (
                        <div className="text-xxs text-emerald-400 font-mono flex items-center gap-0.5 font-bold">
                          <TrendingDown size={10} />
                          <span>Pantry Stock Adjusted</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* MEAL PLAN CARDS BREAKDOWN */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* BREAKFAST */}
                    <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 hover:border-slate-700/80 transition-all flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-mono bg-amber-500/10 text-amber-300 px-2 py-0.5 rounded border border-amber-500/20 font-bold uppercase tracking-wider">
                            Breakfast 🥯
                          </span>
                          <span className="text-[10px] text-slate-405 font-mono">{mealPlan.daily_plan.breakfast.prep_time_mins} mins</span>
                        </div>
                        <h5 className="text-sm font-bold text-slate-100 mb-2 leading-snug">{mealPlan.daily_plan.breakfast.name}</h5>
                        <p className="text-xxs text-slate-400 leading-normal italic">"{mealPlan.daily_plan.breakfast.health_benefit}"</p>
                      </div>
                      <div className="mt-4 pt-3 border-t border-slate-850 flex items-center justify-between">
                        <span className="text-[9px] text-slate-500 font-bold">Ingredients Used</span>
                        <button
                          onClick={() => handleSwapRequest(mealPlan.daily_plan.breakfast.name, "Breakfast Recipie")}
                          className="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-0.5 bg-transparent border-0 cursor-pointer"
                        >
                          <RefreshCw size={10} />
                          <span>Swap</span>
                        </button>
                      </div>
                    </div>

                    {/* LUNCH */}
                    <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 hover:border-slate-700/80 transition-all flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-mono bg-blue-500/10 text-blue-300 px-2 py-0.5 rounded border border-blue-500/20 font-bold uppercase tracking-wider">
                            Lunch 🥗
                          </span>
                          <span className="text-[10px] text-slate-405 font-mono">{mealPlan.daily_plan.lunch.prep_time_mins} mins</span>
                        </div>
                        <h5 className="text-sm font-bold text-slate-100 mb-2 leading-snug">{mealPlan.daily_plan.lunch.name}</h5>
                        <p className="text-xxs text-slate-400 leading-normal italic">"{mealPlan.daily_plan.lunch.health_benefit}"</p>
                      </div>
                      <div className="mt-4 pt-3 border-t border-slate-850 flex items-center justify-between">
                        <span className="text-[9px] text-slate-500 font-bold">Ingredients Used</span>
                        <button
                          onClick={() => handleSwapRequest(mealPlan.daily_plan.lunch.name, "Lunch Recipie")}
                          className="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-0.5 bg-transparent border-0 cursor-pointer"
                        >
                          <RefreshCw size={10} />
                          <span>Swap</span>
                        </button>
                      </div>
                    </div>

                    {/* DINNER */}
                    <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 hover:border-slate-700/80 transition-all flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-mono bg-pink-500/10 text-pink-300 px-2 py-0.5 rounded border border-pink-500/20 font-bold uppercase tracking-wider">
                            Dinner 🍲
                          </span>
                          <span className="text-[10px] text-slate-405 font-mono">{mealPlan.daily_plan.dinner.prep_time_mins} mins</span>
                        </div>
                        <h5 className="text-sm font-bold text-slate-100 mb-2 leading-snug">{mealPlan.daily_plan.dinner.name}</h5>
                        <p className="text-xxs text-slate-400 leading-normal italic">"{mealPlan.daily_plan.dinner.health_benefit}"</p>
                      </div>
                      <div className="mt-4 pt-3 border-t border-slate-850 flex items-center justify-between">
                        <span className="text-[9px] text-slate-500 font-bold">Ingredients Used</span>
                        <button
                          onClick={() => handleSwapRequest(mealPlan.daily_plan.dinner.name, "Dinner Recipie")}
                          className="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-0.5 bg-transparent border-0 cursor-pointer"
                        >
                          <RefreshCw size={10} />
                          <span>Swap</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* CHRONOLOGICAL MASTER TODO CHECKLIST */}
                  <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
                    <div>
                      <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                        <CheckCircle2 size={16} className="text-emerald-405" />
                        {t("checklist_prep_header")}
                      </h4>
                      <p className="text-xs text-slate-400">Mark off steps chronologically while you cook your meals today.</p>
                    </div>

                    <div className="space-y-2">
                      {mealPlan.chronological_todo_list.map((todo, idx) => {
                        const isDone = completedTodos[idx];
                        const timeColor =
                          todo.time_tag.toLowerCase() === "morning"
                            ? "bg-amber-500/10 text-amber-400"
                            : todo.time_tag.toLowerCase() === "afternoon"
                            ? "bg-blue-500/10 text-blue-400"
                            : "bg-pink-500/10 text-pink-400";

                        return (
                          <div
                            key={idx}
                            onClick={() => handleToggleTodo(idx)}
                            className={`flex items-start gap-3 p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                              isDone
                                ? "bg-slate-900/30 border-slate-850 opacity-60 line-through"
                                : "bg-slate-900 border-slate-800/80 hover:border-slate-700"
                            }`}
                          >
                            <div className="pt-0.5 flex-none">
                              <div
                                className={`w-4 h-4 rounded border flex items-center justify-center ${
                                  isDone ? "bg-emerald-500 border-emerald-500 text-slate-905" : "border-slate-600"
                                }`}
                              >
                                {isDone && <Check size={12} strokeWidth={3} />}
                              </div>
                            </div>
                            <div className="flex-1">
                              <p className={`text-xs ${isDone ? "text-slate-500" : "text-slate-205"}`}>
                                {todo.task}
                              </p>
                              <span className={`text-[9px] font-mono rounded px-1.5 py-0.5 mt-1 inline-block ${timeColor}`}>
                                {todo.time_tag}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* GROCERY AND SHOPPING LIST REQUISITIONED */}
                  <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
                    <div>
                      <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                        <Activity size={16} className="text-emerald-400" />
                        {t("grocery_list_header")}
                      </h4>
                      <p className="text-xs text-slate-400">Ingredients needed. Pantry stock items highlighted in green. Check items off as you buy or retrieve them.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {mealPlan.grocery_list.map((g, idx) => {
                        const isBought = completedShopping[idx];
                        return (
                          <div
                            key={idx}
                            onClick={() => {
                              setCompletedShopping((prev) => ({
                                ...prev,
                                [idx]: !prev[idx],
                              }));
                            }}
                            className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer select-none transition-all ${
                              isBought
                                ? "bg-slate-900/40 border-slate-850 opacity-55 line-through"
                                : g.is_in_fridge
                                ? "bg-emerald-950/10 border-emerald-500/20 text-emerald-300 hover:border-emerald-500/30"
                                : "bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              {/* shopping checklist tick checkbox marker */}
                              <div
                                className={`w-4 h-4 rounded border flex items-center justify-center flex-none ${
                                  isBought ? "bg-emerald-500 border-emerald-500 text-slate-950" : "border-slate-600"
                                }`}
                              >
                                {isBought && <Check size={11} strokeWidth={3.5} />}
                              </div>

                              <div>
                                <span className={`text-xs capitalize font-semibold tracking-tight flex items-center gap-1 ${isBought ? "text-slate-500 line-through" : ""}`}>
                                  <span>{getIngredientEmoji(g.item)}</span>
                                  <span>{g.item}</span>
                                </span>
                                <span className="text-[10px] block text-slate-400">Required: {g.qty}</span>
                              </div>
                            </div>

                            <div className="text-right">
                              <span className="text-xs font-mono font-bold block">
                                {g.is_in_fridge ? "In Pantry" : `${g.est_cost_inr} INR`}
                              </span>
                              <span className="text-[9px] text-slate-505 block font-medium">
                                {isBought ? "Got It! ✅" : g.is_in_fridge ? "Stocked ✅" : "Needs buying 🛒"}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                </div>
              )}

            </section>
          </div>
        )}
      </main>

      {/* SWAP INGREDIENT ALTERNATIVE DRAWER / MODAL */}
      <AnimatePresence>
        {isSwapModalOpen && swapTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-slate-800 max-w-lg w-full rounded-2xl shadow-2xl p-6 relative overflow-hidden"
            >
              <button
                onClick={() => setIsSwapModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                <X size={18} />
              </button>

              <h4 className="text-md font-bold text-slate-100 flex items-center gap-2 mb-2">
                <RefreshCw size={16} className="text-emerald-400 animate-spin" />
                Query Smart AI Substitute
              </h4>
              <p className="text-xs text-slate-400 mb-4">
                Ask Gemini to suggest an alternative for <span className="text-emerald-400 font-bold">"{swapTarget}"</span> matching your allergic constraints.
              </p>

              <div className="bg-slate-950 p-4 rounded-xl space-y-3.5 mb-5 border border-slate-850">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider mb-1">Target ingredient</span>
                  <div className="text-xs font-semibold text-slate-200 capitalize">{swapTarget}</div>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider mb-1">Recipe cooking context</span>
                  <input
                    type="text"
                    value={swapContext}
                    onChange={(e) => setSwapContext(e.target.value)}
                    placeholder="e.g. Needs to fit in an Indian pan curry recipe"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-slate-700"
                  />
                </div>
              </div>

              {!swapResults ? (
                <button
                  onClick={handleQuerySubstitute}
                  disabled={isSwapping}
                  className="w-full py-3 rounded-xl font-bold bg-emerald-505 hover:bg-emerald-400 bg-emerald-400 hover:bg-emerald-300 text-slate-950 transition-all font-sans text-xs cursor-pointer flex items-center justify-center gap-1.5"
                >
                  {isSwapping ? (
                    <>
                      <Loader2 size={14} className="animate-spin text-slate-900" />
                      <span>Formulating Ideal SWAP...</span>
                    </>
                  ) : (
                    "Find AI Alternatives"
                  )}
                </button>
              ) : (
                <div className="space-y-4">
                  <div className="bg-emerald-900/10 border border-emerald-500/25 p-4 rounded-xl space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-emerald-400 capitalize">{swapResults.substitute_name}</span>
                      <span className="text-[10px] font-mono bg-emerald-400/10 text-emerald-300 px-2 rounded-full font-bold">
                        {swapResults.cost_difference_inr < 0 
                          ? `${Math.abs(swapResults.cost_difference_inr)} INR Saved 👍` 
                          : `+${swapResults.cost_difference_inr} INR Cost`}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-normal">{swapResults.reason}</p>
                    {swapResults.alternative_recipe_steps_brief && (
                      <div className="mt-2 text-[11px] text-slate-400">
                        <strong className="text-slate-300">Replacement steps: </strong>
                        {swapResults.alternative_recipe_steps_brief}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setSwapResults(null)}
                      type="button"
                      className="flex-1 py-2.5 rounded-xl font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
                    >
                      Try different query
                    </button>
                    <button
                      onClick={applySubstitute}
                      type="button"
                      className="flex-1 py-2.5 rounded-xl font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs cursor-pointer"
                    >
                      Apply and update plan
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MULTI STEP ONBOARDING AND PROFILE PROFILE EDIT DIALOGUE */}
      <AnimatePresence>
        {isOnboardingOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-slate-800 max-w-xl w-full rounded-2xl shadow-2xl overflow-hidden relative"
            >
              {profile && (
                <button
                  onClick={() => setIsOnboardingOpen(false)}
                  className="absolute top-4 right-4 text-slate-450 hover:text-slate-200 cursor-pointer p-1 rounded-full hover:bg-slate-800"
                >
                  <X size={18} />
                </button>
              )}

              {/* Header */}
              <div className="bg-slate-950 px-6 py-5 border-b border-slate-850">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Heart className="text-emerald-405 fill-emerald-500/25" size={18} />
                  {profile ? "Adjust Culinary Settings" : "Culinary Onboarding Profile"}
                </h3>
                <p className="text-xs text-slate-400">
                  Align dietary, allergic, health conditions &amp; budget presets to configure the AI recipes.
                </p>
              </div>

              {/* Progress and step rendering */}
              <div className="px-6 py-4 bg-slate-900 border-b border-slate-850 flex items-center gap-2.5 justify-center">
                <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${onboardingStep === 1 ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>1. Diet &amp; Demographics</span>
                <div className="w-6 h-px bg-slate-800" />
                <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${onboardingStep === 2 ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>2. Allergic Constraints</span>
                <div className="w-6 h-px bg-slate-800" />
                <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${onboardingStep === 3 ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>3. Health &amp; Budget</span>
              </div>

              {/* STEP CONTROLS */}
              <div className="p-6 space-y-5 max-h-[50vh] overflow-y-auto">
                {onboardingStep === 1 && (
                  <div className="space-y-4">
                    {/* Age Group */}
                    <div>
                      <label className="text-xs font-bold text-slate-400 block mb-1.5 uppercase tracking-wider">Demographic Category</label>
                      <select
                        value={formAge}
                        onChange={(e) => setFormAge(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 outline-none"
                      >
                        <option>Child (Growth focus)</option>
                        <option>Adult</option>
                        <option>Senior (Digestion &amp; cardiovascular Focus)</option>
                      </select>
                    </div>

                    {/* Diet Choice */}
                    <div>
                      <label className="text-xs font-bold text-slate-400 block mb-1.5 uppercase tracking-wider">Dietary Preferences</label>
                      <div className="grid grid-cols-2 gap-2">
                        {DIET_OPTIONS.map((opt) => (
                          <button
                            key={opt}
                            onClick={() => setFormDiet(opt)}
                            type="button"
                            className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition-all cursor-pointer ${
                              formDiet === opt
                                ? "bg-emerald-500/10 border-emerald-500 text-emerald-400"
                                : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700"
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {onboardingStep === 2 && (
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-400 block mb-1 uppercase tracking-wider">Allergens to Avoid</label>
                    <p className="text-[11px] text-slate-500 mb-2">Ingredients with chosen allergen fields will be programmatically filtered by the AI.</p>
                    <div className="grid grid-cols-2 gap-2">
                      {ALLERGY_OPTIONS.map((opt) => {
                        const active = formAllergies.includes(opt);
                        return (
                          <button
                            key={opt}
                            onClick={() => toggleAllergy(opt)}
                            type="button"
                            className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition-all cursor-pointer flex justify-between items-center ${
                              active
                                ? "bg-amber-500/10 border-amber-500 text-amber-400"
                                : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700"
                            }`}
                          >
                            <span>{opt}</span>
                            {active && <Check size={14} className="text-amber-400" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {onboardingStep === 3 && (
                  <div className="space-y-4">
                    {/* Health Choice */}
                    <div>
                      <label className="text-xs font-bold text-slate-400 block mb-1 uppercase tracking-wider">Health Constraints &amp; Conditions</label>
                      <p className="text-[11px] text-slate-500 mb-2.5">Align food guidelines to clinical profile diets.</p>
                      <div className="space-y-2">
                        {HEALTH_OPTIONS.map((opt) => {
                          const active = formHealth.includes(opt);
                          return (
                            <button
                              key={opt}
                              onClick={() => toggleHealth(opt)}
                              type="button"
                              className={`w-full p-2.5 rounded-xl border text-left text-xs font-semibold transition-all cursor-pointer flex justify-between items-center ${
                                active
                                  ? "bg-blue-500/10 border-blue-500 text-blue-400"
                                  : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700"
                              }`}
                            >
                              <span>{opt}</span>
                              {active && <Check size={14} className="text-blue-405" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Budget constraints */}
                    <div>
                      <div className="flex justify-between mb-1.1">
                        <label className="text-xs font-bold text-slate-400 block uppercase tracking-wider">Est. Maximum Daily Budget Goal</label>
                        <span className="text-xs font-bold text-emerald-400 font-mono">{formBudget} INR</span>
                      </div>
                      <input
                        type="range"
                        min="200"
                        max="2000"
                        step="50"
                        value={formBudget}
                        onChange={(e) => setFormBudget(Number(e.target.value))}
                        className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                      />
                      <div className="flex justify-between text-[10px] text-slate-550 mt-1 font-bold">
                        <span>200 INR (Highly Frugal)</span>
                        <span>2,000 INR</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* FOOTER ACTIONS */}
              <div className="bg-slate-950 px-6 py-4 flex justify-between items-center gap-3 border-t border-slate-850">
                <button
                  type="button"
                  onClick={() => {
                    if (onboardingStep > 1) {
                      setOnboardingStep(onboardingStep - 1);
                    } else if (profile) {
                      setIsOnboardingOpen(false);
                    }
                  }}
                  className={`px-4 py-2.5 text-xs font-bold rounded-lg border ${
                    onboardingStep === 1 && !profile
                      ? "opacity-30 pointer-events-none"
                      : "bg-slate-900 border-slate-800 text-slate-350 hover:bg-slate-800"
                  } cursor-pointer`}
                >
                  Back
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (onboardingStep < 3) {
                      setOnboardingStep(onboardingStep + 1);
                    } else {
                      handleSaveProfile(true);
                    }
                  }}
                  className="px-5 py-2.5 text-xs font-bold rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md cursor-pointer"
                >
                  {onboardingStep === 3 ? (profile ? "Save Adjustment Settings" : "Complete Profiles & Start Cooking") : "Continue"}
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
