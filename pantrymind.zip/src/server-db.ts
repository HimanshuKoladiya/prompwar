import fs from "fs";
import path from "path";
import { User, InventoryItem, IngredientPricing, MealHistory } from "./types.js";

const DB_FILE = path.join(process.cwd(), "data", "db.json");

interface DBStructure {
  users: User[];
  inventory: InventoryItem[];
  ingredients_pricing: IngredientPricing[];
  meal_history: MealHistory[];
}

const DEFAULT_PRICING: Omit<IngredientPricing, "id">[] = [
  { ingredient_name: "tomato", est_price_per_100g: 5 },
  { ingredient_name: "onion", est_price_per_100g: 4 },
  { ingredient_name: "paneer", est_price_per_100g: 40 },
  { ingredient_name: "chicken breast", est_price_per_100g: 30 },
  { ingredient_name: "spinach", est_price_per_100g: 8 },
  { ingredient_name: "garlic", est_price_per_100g: 15 },
  { ingredient_name: "ginger", est_price_per_100g: 12 },
  { ingredient_name: "potato", est_price_per_100g: 3 },
  { ingredient_name: "oil", est_price_per_100g: 18 },
  { ingredient_name: "butter", est_price_per_100g: 50 },
  { ingredient_name: "rice", est_price_per_100g: 6 },
  { ingredient_name: "flour", est_price_per_100g: 4 },
  { ingredient_name: "milk", est_price_per_100g: 6 },
  { ingredient_name: "eggs", est_price_per_100g: 15 },
  { ingredient_name: "mushroom", est_price_per_100g: 20 },
  { ingredient_name: "bell pepper", est_price_per_100g: 12 },
  { ingredient_name: "cheese", est_price_per_100g: 45 },
  { ingredient_name: "salt", est_price_per_100g: 2 },
  { ingredient_name: "yogurt", est_price_per_100g: 8 },
  { ingredient_name: "coriander", est_price_per_100g: 10 },
  { ingredient_name: "chili", est_price_per_100g: 12 },
  { ingredient_name: "lemon", est_price_per_100g: 10 },
];

class Database {
  private data: DBStructure = {
    users: [],
    inventory: [],
    ingredients_pricing: [],
    meal_history: [],
  };

  constructor() {
    this.load();
  }

  private load() {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, "utf-8");
        this.data = JSON.parse(fileContent);
      } else {
        this.data = {
          users: [],
          inventory: [],
          ingredients_pricing: DEFAULT_PRICING.map((p, idx) => ({
            id: `p-${idx + 1}`,
            ...p,
          })),
          meal_history: [],
        };
        this.save();
      }
    } catch (error) {
      console.error("Failed to load database:", error);
    }
  }

  private save() {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), "utf-8");
    } catch (error) {
      console.error("Failed to save database:", error);
    }
  }

  // --- Users ---
  getUsers(): User[] {
    return this.data.users;
  }

  getUser(id: string): User | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  upsertUser(user: Omit<User, "created_at"> & { created_at?: string }): User {
    const existingIndex = this.data.users.findIndex((u) => u.id === user.id);
    const now = new Date().toISOString();
    
    const finalUser: User = {
      ...user,
      created_at: user.created_at || (existingIndex >= 0 ? this.data.users[existingIndex].created_at : now),
    };

    if (existingIndex >= 0) {
      this.data.users[existingIndex] = finalUser;
    } else {
      this.data.users.push(finalUser);
    }
    this.save();
    return finalUser;
  }

  // --- Inventory ---
  getInventory(userId: string): InventoryItem[] {
    return this.data.inventory.filter((item) => item.user_id === userId);
  }

  upsertInventoryItem(userId: string, ingredientName: string, quantity: number): InventoryItem {
    const lowerName = ingredientName.trim().toLowerCase();
    const existingIndex = this.data.inventory.findIndex(
      (item) => item.user_id === userId && item.ingredient_name.toLowerCase() === lowerName
    );

    const now = new Date().toISOString();

    if (existingIndex >= 0) {
      this.data.inventory[existingIndex].quantity = quantity;
      this.data.inventory[existingIndex].added_date = now;
      this.save();
      return this.data.inventory[existingIndex];
    } else {
      const newItem: InventoryItem = {
        id: `inv-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        user_id: userId,
        ingredient_name: ingredientName.trim(),
        quantity,
        added_date: now,
      };
      this.data.inventory.push(newItem);
      this.save();
      return newItem;
    }
  }

  deleteInventoryItem(userId: string, itemId: string): boolean {
    const initialLength = this.data.inventory.length;
    this.data.inventory = this.data.inventory.filter((item) => !(item.user_id === userId && item.id === itemId));
    if (this.data.inventory.length !== initialLength) {
      this.save();
      return true;
    }
    return false;
  }

  clearInventory(userId: string) {
    this.data.inventory = this.data.inventory.filter((item) => item.user_id !== userId);
    this.save();
  }

  // --- Ingredients Pricing ---
  getPricing(): IngredientPricing[] {
    return this.data.ingredients_pricing;
  }

  getPricePer100g(ingredientName: string): number {
    const lowerName = ingredientName.trim().toLowerCase();
    // Try exact pattern match or substring match
    const found = this.data.ingredients_pricing.find(
      (p) => p.ingredient_name.toLowerCase() === lowerName || lowerName.includes(p.ingredient_name.toLowerCase())
    );
    return found ? found.est_price_per_100g : 15; // default 15 INR per 100g if unknown
  }

  upsertPricing(ingredientName: string, estPricePer100g: number): IngredientPricing {
    const lowerName = ingredientName.trim().toLowerCase();
    const existingIndex = this.data.ingredients_pricing.findIndex(
      (p) => p.ingredient_name.toLowerCase() === lowerName
    );

    if (existingIndex >= 0) {
      this.data.ingredients_pricing[existingIndex].est_price_per_100g = estPricePer100g;
      this.save();
      return this.data.ingredients_pricing[existingIndex];
    } else {
      const newPricing: IngredientPricing = {
        id: `price-${Date.now()}`,
        ingredient_name: ingredientName.trim(),
        est_price_per_100g: estPricePer100g,
      };
      this.data.ingredients_pricing.push(newPricing);
      this.save();
      return newPricing;
    }
  }

  // --- Meal History ---
  getMealHistory(userId: string): MealHistory[] {
    return this.data.meal_history.filter((m) => m.user_id === userId);
  }

  addMealHistory(userId: string, plan: any, totalCost: number): MealHistory {
    const newHistory: MealHistory = {
      id: `meal-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      user_id: userId,
      meal_date: new Date().toISOString().split("T")[0],
      plan_json: plan,
      total_cost: totalCost,
    };
    this.data.meal_history.push(newHistory);
    this.save();
    return newHistory;
  }
}

export const db = new Database();
