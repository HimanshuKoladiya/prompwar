export interface User {
  id: string;
  age_group: string;
  diet: string;
  allergies: string[];
  health_conditions: string[];
  daily_budget: number;
  created_at: string;
}

export interface InventoryItem {
  id: string;
  user_id: string;
  ingredient_name: string;
  quantity: number; // in grams
  added_date: string;
}

export interface IngredientPricing {
  id: string;
  ingredient_name: string;
  est_price_per_100g: number; // in INR or user's currency
}

export interface MealHistory {
  id: string;
  user_id: string;
  meal_date: string;
  plan_json: DailyPlanResponse;
  total_cost: number;
}

export interface MealDetail {
  name: string;
  prep_time_mins: number;
  health_benefit: string;
  ingredients_used?: string[];
}

export interface DailyPlanResponse {
  daily_plan: {
    breakfast: MealDetail;
    lunch: MealDetail;
    dinner: MealDetail;
  };
  chronological_todo_list: {
    task: string;
    time_tag: "Morning" | "Afternoon" | "Evening" | string;
  }[];
  grocery_list: {
    item: string;
    qty: string;
    est_cost_inr: number;
    is_in_fridge: boolean;
  }[];
  total_budget_used: number;
}
